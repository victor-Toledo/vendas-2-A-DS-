'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Venda extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Vendedor.hasMany(models.Venda, {
        foreignKey: 'VendaId',
      });
      Venda.belongsTo(models.Cliente);
    }
  }
  Venda.init({
    date: DataTypes.DATE,
    ClienteId: DataTypes.INTEGER,
    Vendedor: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Venda',
  });
  return Venda;
};